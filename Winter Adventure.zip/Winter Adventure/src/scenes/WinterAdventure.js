import Phaser, { Create } from "phaser";

export default class WinterAdventureScene extends
Phaser.Scene
{
    constructor()
    {
        super('winter-adventure-scene')
    }

    init(){
        this.platform = undefined
        this.player = undefined
    }
    preload()
    {
        this.load.image('background','images/background.jpg')
        this.load.image('platform','images/platform.png')
        this.load.spritesheet('Dude','images/Dude.png', {
            frameWidth : 192/6, frameHeight: 32/1
        })
    }
    create()
    {
        this.add.image(400,300,'background')
        this.platform = this.physics.add.staticGroup()
       this.platform.create(600,400,'platform').setScale(0.7)
        this.platform.create(50,250,'platform').setScale(0.7)
        this.platform.create(750,220,'platform').setScale(0.7)
        this.platform.create(400,568,'platform').setScale(1.5).refreshBody()
        this.player = this.physics.add.sprite(100,450,'Dude')
        this.player.setCollideWorldBounds(true)
        this.player.setBounce(0.2)
        this.player.setScale(1.5)
    }
}